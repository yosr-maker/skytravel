#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <gtk/gtk.h>



void afficher1(GtkWidget *liste);
void sup_offre(char chaine[30],FILE *f);
