#include <gtk/gtk.h>


void
on_valider_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonconfirmer_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_buttonn_modifier_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_supprimer_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_affich1_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
