#include <gtk/gtk.h>


void
on_buttonajouter_clicked               (GtkWidget       *button,
                                        gpointer         user_data);
void
on_buttonmodifier_clicked               (GtkWidget       *button,
                                        gpointer         user_data);
void
on_buttonsuprimer_clicked               (GtkWidget       *button,
                                        gpointer         user_data);
void
on_buttonafficher_clicked               (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonback1_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonback2_clicked                 (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttonback3_clicked                 (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonback4_clicked                 (GtkWidget        *button,
                                        gpointer         user_data);

void
on_buttoncree_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonsupp_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonediter_clicked                (GtkWidget      *button,
                                        gpointer         user_data);

void
on_buttonedit_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);

void
on_buttonact_clicked                   (GtkWidget       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkWidget      *button,
                                        gpointer         user_data);

void
on_buttonhome_clicked                  (GtkWidget       *button,
                                        gpointer         user_data);
